package com.sonandhan.boardit.command;

import org.springframework.ui.Model;

public interface BICommand {
	
	void execute(Model model);

}
