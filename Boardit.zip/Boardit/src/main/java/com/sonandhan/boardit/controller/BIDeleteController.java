package com.sonandhan.boardit.controller;

public class BIDeleteController {

}
