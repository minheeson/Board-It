package com.sonandhan.boardit.dao;

import java.util.ArrayList;

import com.sonandhan.boardit.dto.BIDto;

public class BIDao {
	/**
	 * db에 접근해서 일하는애
	 */

	public ArrayList<BIDto> list() {
		// db 접근해서 데이터 가져왕
		// 그리고 ArrayLsit로 넘김

		ArrayList<BIDto> dtos = null;
		return dtos;

	}
}
