package com.sonandhan.boardit.dto;

public class ListDTO {

	private int listNum;
	private String listName;
	private int listParent;

	public int getListNum() {
		return listNum;
	}

	public void setListNum(int listNum) {
		this.listNum = listNum;
	}

	public String getListName() {
		return listName;
	}

	public void setListName(String listName) {
		this.listName = listName;
	}

	public int getListParent() {
		return listParent;
	}

	public void setListParent(int listParent) {
		this.listParent = listParent;
	}

}
