package com.sonandhan.boardit.command;

import org.springframework.ui.Model;

public class BIModifyCommand implements BICommand {

	@Override
	public void execute(Model model) {
		// TODO Auto-generated method stub

	}

}
